package com.aura.assistant;
import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.RecognitionListener;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQUEST_AUDIO = 101;
    private TextView status, heard;
    private SpeechRecognizer recognizer;
    private TextToSpeech tts;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL); root.setGravity(Gravity.CENTER); root.setPadding(28,28,28,28);
        TextView title = new TextView(this); title.setText("AURA"); title.setTextSize(34); title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1,-2));
        status = new TextView(this); status.setText("आपका Assistant तैयार है।"); status.setTextSize(18); status.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1,-2); sp.setMargins(0,30,0,20); root.addView(status,sp);
        heard = new TextView(this); heard.setText("आपकी आवाज़ यहाँ दिखाई देगी।"); heard.setTextSize(16); heard.setGravity(Gravity.CENTER);
        root.addView(heard,new LinearLayout.LayoutParams(-1,-2));
        Button speak = new Button(this); speak.setText("बोलें / SPEAK");
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1,-2); bp.setMargins(0,30,0,0); root.addView(speak,bp);
        speak.setOnClickListener(v -> startListening()); setContentView(root);
        tts = new TextToSpeech(this, result -> { if (result == TextToSpeech.SUCCESS) { int r=tts.setLanguage(new Locale("hi","IN")); if(r==TextToSpeech.LANG_MISSING_DATA || r==TextToSpeech.LANG_NOT_SUPPORTED) tts.setLanguage(Locale.getDefault()); }});
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_AUDIO);
    }
    private void startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},REQUEST_AUDIO); return; }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { status.setText("Speech service उपलब्ध नहीं है। Google app / Speech Services जाँचें।"); return; }
        if (recognizer != null) recognizer.destroy();
        recognizer = SpeechRecognizer.createSpeechRecognizer(this);
        recognizer.setRecognitionListener(new RecognitionListener() {
            @Override public void onReadyForSpeech(Bundle p) { status.setText("सुन रहा हूँ..."); }
            @Override public void onBeginningOfSpeech() {}
            @Override public void onRmsChanged(float r) {}
            @Override public void onBufferReceived(byte[] b) {}
            @Override public void onEndOfSpeech() { status.setText("समझ रहा हूँ..."); }
            @Override public void onError(int e) { status.setText("आवाज़ समझ नहीं आई। दोबारा कोशिश करें। Code: "+e); }
            @Override public void onResults(Bundle b) { ArrayList<String> m=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION); if(m!=null&&!m.isEmpty()){ heard.setText("आपने कहा: "+m.get(0)); respond(m.get(0)); } }
            @Override public void onPartialResults(Bundle b) {}
            @Override public void onEvent(int e, Bundle b) {}
        });
        Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"hi-IN"); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE,"hi-IN");
        try { recognizer.startListening(i); } catch(Exception e) { status.setText("Speech शुरू नहीं हो पाया: "+e.getMessage()); }
    }
    private void respond(String spoken) {
        String s=spoken.toLowerCase(Locale.ROOT), reply;
        if(s.contains("नमस्ते")||s.contains("hello")||s.contains("हेलो")) reply="नमस्ते! मैं ऑरा हूँ। बताइए, मैं आपकी क्या मदद करूँ?";
        else if(s.contains("समय")||s.contains("time")) reply="अभी समय है "+new java.text.SimpleDateFormat("hh:mm a",Locale.getDefault()).format(new java.util.Date());
        else reply="मैंने आपकी बात सुनी: "+spoken+"। अभी मेरा शुरुआती संस्करण है।";
        status.setText(reply); if(tts!=null) tts.speak(reply,TextToSpeech.QUEUE_FLUSH,null,"AURA_REPLY");
    }
    @Override protected void onDestroy() { if(recognizer!=null) recognizer.destroy(); if(tts!=null){tts.stop();tts.shutdown();} super.onDestroy(); }
}
