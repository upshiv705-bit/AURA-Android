package com.aura.assistant;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.RecognitionListener;
import android.speech.tts.TextToSpeech;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.view.Gravity;
import android.graphics.Typeface;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private TextView status;
    private TextToSpeech tts;
    private SpeechRecognizer recognizer;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setGravity(Gravity.CENTER);
        layout.setPadding(32, 32, 32, 32);

        TextView title = new TextView(this);
        title.setText("AURA");
        title.setTextSize(36);
        title.setTypeface(null, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        layout.addView(title);

        status = new TextView(this);
        status.setText("Your Personal AI Assistant\nनमस्ते! मैं AURA हूँ।");
        status.setTextSize(18);
        status.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2);
        sp.setMargins(0, 24, 0, 24);
        layout.addView(status, sp);

        Button speak = new Button(this);
        speak.setText("🎙 बोलें / Speak");
        layout.addView(speak, new LinearLayout.LayoutParams(-1, -2));

        setContentView(layout);

        tts = new TextToSpeech(this, result -> {
            if (result == TextToSpeech.SUCCESS) {
                tts.setLanguage(new Locale("hi", "IN"));
            }
        });

        speak.setOnClickListener(v -> startListening());
    }

    private void startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.setText("इस फोन पर Speech Recognition उपलब्ध नहीं है।");
            return;
        }
        if (recognizer != null) recognizer.destroy();
        recognizer = SpeechRecognizer.createSpeechRecognizer(this);
        recognizer.setRecognitionListener(new RecognitionListener() {
            public void onReadyForSpeech(Bundle params) { status.setText("सुन रहा हूँ..."); }
            public void onBeginningOfSpeech() {}
            public void onRmsChanged(float rmsdB) {}
            public void onBufferReceived(byte[] buffer) {}
            public void onEndOfSpeech() { status.setText("समझ रहा हूँ..."); }
            public void onError(int error) { status.setText("आवाज़ समझ नहीं आई। फिर कोशिश करें।"); }
            public void onResults(Bundle results) {
                ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (matches == null || matches.isEmpty()) return;
                String command = matches.get(0);
                status.setText("आपने कहा: " + command);
                String reply;
                String c = command.toLowerCase();
                if (c.contains("hello") || c.contains("नमस्ते") || c.contains("हेलो")) {
                    reply = "नमस्ते! मैं आपकी कैसे मदद करूँ?";
                } else if (c.contains("समय") || c.contains("time")) {
                    reply = "समय देखने के लिए अपने फोन की घड़ी देखें।";
                } else {
                    reply = "मैंने सुना: " + command + "। अभी मेरा बेसिक मोड चालू है।";
                }
                status.setText("आप: " + command + "\nAURA: " + reply);
                if (tts != null) tts.speak(reply, TextToSpeech.QUEUE_FLUSH, null, "aura_reply");
            }
            public void onPartialResults(Bundle partialResults) {}
            public void onEvent(int eventType, Bundle params) {}
        });
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN");
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN");
        recognizer.startListening(intent);
    }

    @Override
    protected void onDestroy() {
        if (recognizer != null) recognizer.destroy();
        if (tts != null) tts.shutdown();
        super.onDestroy();
    }
}
