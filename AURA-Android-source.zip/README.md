# AURA Android starter
Basic Hindi speech-recognition and text-to-speech starter project. This is not yet a full AI assistant. Speech recognition requires an installed Android speech recognition provider and may require internet access.

Build using JDK 17 and Gradle 8.9: `gradle assembleDebug`
APK output: `app/build/outputs/apk/debug/app-debug.apk`
