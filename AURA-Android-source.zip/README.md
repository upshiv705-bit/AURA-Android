# AURA Android

A minimal native Android starter app for the AURA assistant project.

Current starter features:
- Hindi speech recognition using Android's speech recognition service
- Hindi text-to-speech replies
- Basic sample commands

This is a starter build, not the finished AI assistant. Online AI, offline command expansion,
and accessibility-based phone controls will be added in later steps with explicit permissions
and user confirmation for sensitive actions.
