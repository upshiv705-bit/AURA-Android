# AURA Android Assistant — Source 1.0.7

- Android application ID remains `com.aura.assistant`.
- Version: 1.0.7 (versionCode 8).
- Improved voice-command matching for installed launcher apps, including MX Player, JioHotstar/Hotstar, and Music.
- Uses Android launcher activities discovered through PackageManager; apps without a launcher activity cannot be opened this way.
- Gemini chat continues through the configured Cloudflare Worker endpoint.
- Keep `GEMINI_API_KEY` only as a Cloudflare Worker secret.

Build with Java 17 and Gradle 8.9:
`gradle assembleDebug`

APK output:
`app/build/outputs/apk/debug/app-debug.apk`
