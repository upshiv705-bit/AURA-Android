package com.aura.assistant;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int REQUEST_AUDIO = 101;
    private static final String WORKER_URL = "https://aura-ai-server.upshiv705.workers.dev";
    private TextView statusText;
    private TextView conversationText;
    private Button speakButton;
    private SpeechRecognizer speechRecognizer;
    private TextToSpeech textToSpeech;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildScreen();

        textToSpeech = new TextToSpeech(this, result -> {
            if (result == TextToSpeech.SUCCESS) {
                textToSpeech.setLanguage(new Locale("hi", "IN"));
            }
        });

        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_AUDIO);
        } else {
            prepareSpeechRecognizer();
        }

        speakButton.setOnClickListener(v -> startListening());
    }

    private void buildScreen() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28, 36, 28, 24);
        root.setGravity(Gravity.CENTER_HORIZONTAL);

        TextView title = new TextView(this);
        title.setText("AURA");
        title.setTextSize(34);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 8, 0, 8);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView subtitle = new TextView(this);
        subtitle.setText("Your Personal AI Assistant");
        subtitle.setTextSize(16);
        subtitle.setGravity(Gravity.CENTER);
        root.addView(subtitle, new LinearLayout.LayoutParams(-1, -2));

        statusText = new TextView(this);
        statusText.setText("तैयार हूँ। बोलने के लिए नीचे दबाएँ।");
        statusText.setTextSize(16);
        statusText.setPadding(0, 24, 0, 16);
        root.addView(statusText, new LinearLayout.LayoutParams(-1, -2));

        ScrollView scroll = new ScrollView(this);
        conversationText = new TextView(this);
        conversationText.setText("AURA: नमस्ते! मैं आपकी AI assistant हूँ।");
        conversationText.setTextSize(17);
        conversationText.setPadding(14, 14, 14, 14);
        scroll.addView(conversationText);
        LinearLayout.LayoutParams scrollParams = new LinearLayout.LayoutParams(-1, 0, 1);
        scrollParams.setMargins(0, 12, 0, 18);
        root.addView(scroll, scrollParams);

        speakButton = new Button(this);
        speakButton.setText("बोलें / SPEAK");
        speakButton.setTextSize(18);
        root.addView(speakButton, new LinearLayout.LayoutParams(-1, -2));

        setContentView(root);
    }

    private void prepareSpeechRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            statusText.setText("इस फोन में Speech Recognition उपलब्ध नहीं है।");
            speakButton.setEnabled(false);
            return;
        }

        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
        speechRecognizer.setRecognitionListener(new android.speech.RecognitionListener() {
            @Override public void onReadyForSpeech(Bundle params) {
                statusText.setText("सुन रहा हूँ...");
            }
            @Override public void onBeginningOfSpeech() { }
            @Override public void onRmsChanged(float rmsdB) { }
            @Override public void onBufferReceived(byte[] buffer) { }
            @Override public void onEndOfSpeech() {
                statusText.setText("आपकी बात समझ रहा हूँ...");
            }
            @Override public void onError(int error) {
                statusText.setText("आवाज़ समझ नहीं आई। फिर से कोशिश करें।");
                speakButton.setEnabled(true);
            }
            @Override public void onResults(Bundle results) {
                ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (matches != null && !matches.isEmpty()) {
                    askAura(matches.get(0));
                } else {
                    statusText.setText("कुछ सुनाई नहीं दिया। फिर से बोलें।");
                    speakButton.setEnabled(true);
                }
            }
            @Override public void onPartialResults(Bundle partialResults) { }
            @Override public void onEvent(int eventType, Bundle params) { }
        });
    }

    private void startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_AUDIO);
            return;
        }
        if (speechRecognizer == null) {
            prepareSpeechRecognizer();
        }
        if (speechRecognizer == null) return;

        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN");
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN");
        intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
        speakButton.setEnabled(false);
        speechRecognizer.startListening(intent);
    }

    private void askAura(String question) {
        runOnUiThread(() -> {
            conversationText.append("\n\nआप: " + question + "\n\nAURA: जवाब तैयार कर रही हूँ...");
            statusText.setText("AI से जुड़ रहा हूँ...");
        });

        executor.execute(() -> {
            HttpURLConnection connection = null;
            try {
                URL url = new URL(WORKER_URL);
                connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("POST");
                connection.setConnectTimeout(20000);
                connection.setReadTimeout(30000);
                connection.setDoOutput(true);
                connection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");

                JSONObject payload = new JSONObject();
                payload.put("message", question);
                byte[] bytes = payload.toString().getBytes(StandardCharsets.UTF_8);

                try (OutputStream output = connection.getOutputStream()) {
                    output.write(bytes);
                }

                int code = connection.getResponseCode();
                InputStream stream = (code >= 200 && code < 300)
                        ? connection.getInputStream() : connection.getErrorStream();

                StringBuilder responseText = new StringBuilder();
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
                    String line;
                    while ((line = reader.readLine()) != null) responseText.append(line);
                }

                JSONObject response = new JSONObject(responseText.toString());
                if (code >= 200 && code < 300) {
                    String reply = response.optString("reply", "माफ कीजिए, जवाब नहीं मिला।");
                    showReply(reply);
                } else {
                    String error = response.optString("error", "AI server में समस्या है।");
                    showReply("माफ कीजिए, " + error);
                }
            } catch (Exception e) {
                showReply("माफ कीजिए, इंटरनेट या AI server से कनेक्शन नहीं हो पाया।");
            } finally {
                if (connection != null) connection.disconnect();
            }
        });
    }

    private void showReply(String reply) {
        runOnUiThread(() -> {
            String current = conversationText.getText().toString();
            int marker = current.lastIndexOf("AURA: जवाब तैयार कर रही हूँ...");
            if (marker >= 0) {
                conversationText.setText(current.substring(0, marker) + "AURA: " + reply);
            } else {
                conversationText.append("\n\nAURA: " + reply);
            }
            statusText.setText("जवाब मिल गया। फिर बोल सकते हैं।");
            speakButton.setEnabled(true);
            if (textToSpeech != null) {
                textToSpeech.speak(reply, TextToSpeech.QUEUE_FLUSH, null, "aura_reply");
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_AUDIO) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                prepareSpeechRecognizer();
            } else {
                statusText.setText("बोलने के लिए Microphone permission जरूरी है।");
            }
        }
    }

    @Override
    protected void onDestroy() {
        if (speechRecognizer != null) {
            speechRecognizer.destroy();
            speechRecognizer = null;
        }
        if (textToSpeech != null) {
            textToSpeech.stop();
            textToSpeech.shutdown();
        }
        executor.shutdownNow();
        super.onDestroy();
    }
}
