package com.aura.assistant;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int REQUEST_MIC = 101;
    private static final String WORKER_URL =
            "https://aura-ai-server.upshiv705.workers.dev";

    private TextView statusText;
    private TextView conversationText;
    private Button micButton;
    private SpeechRecognizer speechRecognizer;
    private TextToSpeech tts;
    private ExecutorService executor;
    private boolean ttsReady = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        executor = Executors.newSingleThreadExecutor();
        buildScreen();

        tts = new TextToSpeech(this, result -> {
            if (result == TextToSpeech.SUCCESS) {
                int languageResult = tts.setLanguage(new Locale("hi", "IN"));
                ttsReady = languageResult != TextToSpeech.LANG_MISSING_DATA
                        && languageResult != TextToSpeech.LANG_NOT_SUPPORTED;
                if (!ttsReady) {
                    tts.setLanguage(Locale.getDefault());
                    ttsReady = true;
                }
            }
        });

        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
        } else {
            statusText.setText("Speech recognition is not available on this phone.");
            micButton.setEnabled(false);
        }

        micButton.setOnClickListener(v -> startListening());
    }

    private void buildScreen() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24, 28, 24, 24);
        root.setBackgroundColor(0xFFF4F7FB);

        TextView title = new TextView(this);
        title.setText("AURA – Your Personal AI Assistant");
        title.setTextSize(23);
        title.setTextColor(0xFF172554);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 10, 0, 18);
        root.addView(title);

        statusText = new TextView(this);
        statusText.setText("Ready. Tap the microphone and speak.");
        statusText.setTextSize(15);
        statusText.setTextColor(0xFF334155);
        statusText.setPadding(4, 8, 4, 14);
        root.addView(statusText);

        ScrollView scroll = new ScrollView(this);
        conversationText = new TextView(this);
        conversationText.setText("Namaste! Main AURA hoon. Aap mujhse Hindi ya English mein baat kar sakte hain.\n\nExample: \"YouTube kholo\"");
        conversationText.setTextSize(17);
        conversationText.setTextColor(0xFF111827);
        conversationText.setPadding(14, 18, 14, 18);
        conversationText.setBackgroundColor(0xFFFFFFFF);
        scroll.addView(conversationText);
        LinearLayout.LayoutParams scrollParams =
                new LinearLayout.LayoutParams(-1, 0, 1);
        scrollParams.setMargins(0, 8, 0, 18);
        root.addView(scroll, scrollParams);

        micButton = new Button(this);
        micButton.setText("🎙  Speak to AURA");
        micButton.setAllCaps(false);
        root.addView(micButton, new LinearLayout.LayoutParams(-1, -2));

        TextView hint = new TextView(this);
        hint.setText("Try: YouTube kholo / Open WhatsApp");
        hint.setTextSize(13);
        hint.setTextColor(0xFF64748B);
        hint.setGravity(Gravity.CENTER);
        hint.setPadding(0, 12, 0, 0);
        root.addView(hint);

        setContentView(root);
    }

    private void startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_MIC);
            return;
        }
        if (speechRecognizer == null) {
            speakAndShow("Speech recognition available nahi hai.");
            return;
        }

        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN");
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN");
        intent.putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, false);
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "AURA ko apna command boliye");

        statusText.setText("Listening...");
        micButton.setEnabled(false);

        speechRecognizer.setRecognitionListener(new android.speech.RecognitionListener() {
            @Override public void onReadyForSpeech(Bundle params) {
                statusText.setText("Sun raha hoon...");
            }
            @Override public void onBeginningOfSpeech() {}
            @Override public void onRmsChanged(float rmsdB) {}
            @Override public void onBufferReceived(byte[] buffer) {}
            @Override public void onEndOfSpeech() {
                statusText.setText("Processing...");
            }
            @Override public void onError(int error) {
                statusText.setText("Voice input error. Please try again.");
                micButton.setEnabled(true);
            }
            @Override public void onResults(Bundle results) {
                ArrayList<String> matches =
                        results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                micButton.setEnabled(true);
                if (matches != null && !matches.isEmpty()) {
                    handleUserMessage(matches.get(0));
                } else {
                    statusText.setText("Awaaz samajh nahi aayi. Dobara boliye.");
                }
            }
            @Override public void onPartialResults(Bundle partialResults) {}
            @Override public void onEvent(int eventType, Bundle params) {}
        });
        speechRecognizer.startListening(intent);
    }

    private void handleUserMessage(String message) {
        conversationText.setText("You: " + message + "\n\nAURA: Processing...");
        statusText.setText("Command received");

        String appName = extractAppName(message);
        if (appName != null && launchApp(appName)) {
            String reply = appName + " khol raha hoon.";
            conversationText.setText("You: " + message + "\n\nAURA: " + reply);
            statusText.setText("App launch command completed");
            speak(reply);
            return;
        }

        if (appName != null) {
            String reply = appName + " app is phone mein nahi mila.";
            conversationText.setText("You: " + message + "\n\nAURA: " + reply);
            statusText.setText("App not found");
            speak(reply);
            return;
        }

        askGemini(message);
    }

    // Returns an app name only when the sentence looks like an app-opening command.
    private String extractAppName(String raw) {
        String original = raw.toLowerCase(Locale.ROOT);
        String text = normalize(raw);
        String[] openWords = {"open", "launch", "start", "kholo", "khol do",
                "kholna", "khol", "chalao", "चलाओ", "खोलो", "खोल", "चला दो", "चालू करो"};
        boolean isOpenCommand = false;
        for (String word : openWords) {
            if (original.contains(word) || text.contains(word)) {
                isOpenCommand = true;
                break;
            }
        }
        if (!isOpenCommand) return null;

        // Common app names as spoken in Hindi or English.
        String[][] spokenAliases = {
                {"youtube", "यूट्यूब", "यु ट्यूब"},
                {"whatsapp", "व्हाट्सएप", "व्हाट्सऐप"},
                {"chrome", "क्रोम"},
                {"google maps", "गूगल मैप्स", "मैप्स"},
                {"instagram", "इंस्टाग्राम"},
                {"facebook", "फेसबुक"},
                {"telegram", "टेलीग्राम"},
                {"gmail", "जीमेल"},
                {"camera", "कैमरा"},
                {"settings", "सेटिंग्स", "सेटिंग"},
                {"play store", "प्ले स्टोर"},
                {"phone", "फोन"},
                {"messages", "मैसेज", "मैसेजेस"},
                {"gallery", "गैलरी"},
                {"photos", "फोटो"},
                {"spotify", "स्पॉटिफाई"},
                {"calculator", "कैलकुलेटर"},
                {"clock", "घड़ी"}
        };
        for (String[] aliases : spokenAliases) {
            for (String alias : aliases) {
                if (original.contains(alias) || text.contains(normalize(alias))) {
                    return aliases[0];
                }
            }
        }

        // Also match the visible names of launchable apps installed on this phone.
        for (ResolveInfo info : getLaunchableApps()) {
            CharSequence label = info.loadLabel(getPackageManager());
            if (label != null) {
                String appLabel = normalize(label.toString());
                if (!appLabel.isEmpty() && text.contains(appLabel)) {
                    return label.toString();
                }
            }
        }
        return null;
    }

    private List<ResolveInfo> getLaunchableApps() {
        Intent query = new Intent(Intent.ACTION_MAIN, null);
        query.addCategory(Intent.CATEGORY_LAUNCHER);
        return getPackageManager().queryIntentActivities(query, 0);
    }

    private boolean launchApp(String requestedName) {
        String wanted = normalize(requestedName);
        String[] packageAliases = {
                "com.google.android.youtube|youtube",
                "com.whatsapp|whatsapp",
                "com.android.chrome|chrome",
                "com.google.android.apps.maps|maps",
                "com.instagram.android|instagram",
                "com.facebook.katana|facebook",
                "org.telegram.messenger|telegram",
                "com.google.android.gm|gmail",
                "com.android.camera2|camera",
                "com.android.settings|settings",
                "com.android.vending|play store",
                "com.google.android.dialer|phone",
                "com.google.android.apps.messaging|messages",
                "com.google.android.apps.photos|photos",
                "com.spotify.music|spotify",
                "com.google.android.calculator|calculator",
                "com.google.android.deskclock|clock"
        };

        for (String item : packageAliases) {
            String[] parts = item.split("\\|");
            if (wanted.equals(normalize(parts[1])) ||
                    wanted.equals(normalize(parts[1]).replace(" ", ""))) {
                Intent launch = getPackageManager().getLaunchIntentForPackage(parts[0]);
                if (launch != null) {
                    try {
                        startActivity(launch);
                        return true;
                    } catch (Exception ignored) {}
                }
            }
        }

        for (ResolveInfo info : getLaunchableApps()) {
            CharSequence label = info.loadLabel(getPackageManager());
            if (label != null && normalize(label.toString()).equals(wanted)) {
                Intent launch = new Intent(Intent.ACTION_MAIN);
                launch.addCategory(Intent.CATEGORY_LAUNCHER);
                launch.setClassName(info.activityInfo.packageName,
                        info.activityInfo.name);
                try {
                    startActivity(launch);
                    return true;
                } catch (Exception ignored) {}
            }
        }
        return false;
    }

    private String normalize(String value) {
        return Normalizer.normalize(value.toLowerCase(Locale.ROOT).trim(),
                Normalizer.Form.NFD).replaceAll("\\p{M}", "")
                .replaceAll("[^a-z0-9 ]", " ")
                .replaceAll("\\s+", " ");
    }

    private void askGemini(String message) {
        executor.execute(() -> {
            HttpURLConnection connection = null;
            try {
                URL url = new URL(WORKER_URL);
                connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("POST");
                connection.setConnectTimeout(20000);
                connection.setReadTimeout(30000);
                connection.setDoOutput(true);
                connection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");

                JSONObject payload = new JSONObject();
                payload.put("message", message);

                try (OutputStream os = connection.getOutputStream()) {
                    os.write(payload.toString().getBytes(StandardCharsets.UTF_8));
                }

                int code = connection.getResponseCode();
                InputStream stream = (code >= 200 && code < 300)
                        ? connection.getInputStream() : connection.getErrorStream();
                StringBuilder responseText = new StringBuilder();
                try (BufferedReader reader = new BufferedReader(
                        new InputStreamReader(stream, StandardCharsets.UTF_8))) {
                    String line;
                    while ((line = reader.readLine()) != null) responseText.append(line);
                }

                JSONObject result = new JSONObject(responseText.toString());
                if (code < 200 || code >= 300) {
                    String details = result.optString("details",
                            result.optString("error", "Server error"));
                    showReply("AI service error: " + details, false);
                    return;
                }

                String reply = result.optString("reply", "Mujhe jawab nahi mila.");
                showReply(reply, true);

            } catch (Exception e) {
                showReply("Internet ya server connection mein problem hai. " +
                        "Please dobara try karein.", false);
            } finally {
                if (connection != null) connection.disconnect();
            }
        });
    }

    private void showReply(String reply, boolean speakReply) {
        runOnUiThread(() -> {
            conversationText.setText("AURA: " + reply);
            statusText.setText("Ready");
            if (speakReply) speak(reply);
        });
    }

    private void speakAndShow(String message) {
        conversationText.setText("AURA: " + message);
        speak(message);
    }

    private void speak(String text) {
        if (ttsReady && tts != null) {
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "AURA_REPLY");
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions,
                                           int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_MIC && grantResults.length > 0
                && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startListening();
        } else if (requestCode == REQUEST_MIC) {
            statusText.setText("Microphone permission is required for voice commands.");
        }
    }

    @Override
    protected void onDestroy() {
        if (speechRecognizer != null) speechRecognizer.destroy();
        if (tts != null) tts.shutdown();
        if (executor != null) executor.shutdown();
        super.onDestroy();
    }
}
