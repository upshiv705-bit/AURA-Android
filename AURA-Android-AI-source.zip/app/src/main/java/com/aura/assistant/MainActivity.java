package com.aura.assistant;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int REQUEST_MIC = 101;
    private static final String WORKER_URL =
            "https://aura-ai-server.upshiv705.workers.dev";

    private TextView statusText;
    private TextView conversationText;
    private Button micButton;
    private SpeechRecognizer speechRecognizer;
    private TextToSpeech tts;
    private ExecutorService executor;
    private boolean ttsReady = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        executor = Executors.newSingleThreadExecutor();
        buildScreen();

        tts = new TextToSpeech(this, result -> {
            if (result == TextToSpeech.SUCCESS) {
                int languageResult = tts.setLanguage(new Locale("hi", "IN"));
                ttsReady = languageResult != TextToSpeech.LANG_MISSING_DATA
                        && languageResult != TextToSpeech.LANG_NOT_SUPPORTED;
                if (!ttsReady) {
                    tts.setLanguage(Locale.getDefault());
                    ttsReady = true;
                }
            }
        });

        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
        } else {
            statusText.setText("Speech recognition is not available on this phone.");
            micButton.setEnabled(false);
        }

        micButton.setOnClickListener(v -> startListening());
    }

    private void buildScreen() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24, 28, 24, 24);
        root.setBackgroundColor(0xFFF4F7FB);

        TextView title = new TextView(this);
        title.setText("AURA – Your Personal AI Assistant");
        title.setTextSize(23);
        title.setTextColor(0xFF172554);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 10, 0, 18);
        root.addView(title);

        statusText = new TextView(this);
        statusText.setText("Ready. Tap the microphone and speak.");
        statusText.setTextSize(15);
        statusText.setTextColor(0xFF334155);
        statusText.setPadding(4, 8, 4, 14);
        root.addView(statusText);

        ScrollView scroll = new ScrollView(this);
        conversationText = new TextView(this);
        conversationText.setText("Namaste! Main AURA hoon. Aap mujhse Hindi ya English mein baat kar sakte hain.\n\nExample: \"YouTube kholo\" or \"WhatsApp kholo\"");
        conversationText.setTextSize(17);
        conversationText.setTextColor(0xFF111827);
        conversationText.setPadding(14, 18, 14, 18);
        conversationText.setBackgroundColor(0xFFFFFFFF);
        scroll.addView(conversationText);
        LinearLayout.LayoutParams scrollParams =
                new LinearLayout.LayoutParams(-1, 0, 1);
        scrollParams.setMargins(0, 8, 0, 18);
        root.addView(scroll, scrollParams);

        micButton = new Button(this);
        micButton.setText("🎙  Speak to AURA");
        micButton.setAllCaps(false);
        root.addView(micButton, new LinearLayout.LayoutParams(-1, -2));

        TextView hint = new TextView(this);
        hint.setText("Try: YouTube kholo / WhatsApp kholo / Chrome kholo");
        hint.setTextSize(13);
        hint.setTextColor(0xFF64748B);
        hint.setGravity(Gravity.CENTER);
        hint.setPadding(0, 12, 0, 0);
        root.addView(hint);

        setContentView(root);
    }

    private void startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_MIC);
            return;
        }
        if (speechRecognizer == null) {
            speakAndShow("Speech recognition available nahi hai.");
            return;
        }

        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN");
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN");
        intent.putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, false);
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "AURA ko apna command boliye");

        statusText.setText("Listening...");
        micButton.setEnabled(false);

        speechRecognizer.setRecognitionListener(new android.speech.RecognitionListener() {
            @Override public void onReadyForSpeech(Bundle params) {
                statusText.setText("Sun raha hoon...");
            }
            @Override public void onBeginningOfSpeech() {}
            @Override public void onRmsChanged(float rmsdB) {}
            @Override public void onBufferReceived(byte[] buffer) {}
            @Override public void onEndOfSpeech() {
                statusText.setText("Processing...");
            }
            @Override public void onError(int error) {
                statusText.setText("Voice input error. Please try again.");
                micButton.setEnabled(true);
            }
            @Override public void onResults(Bundle results) {
                ArrayList<String> matches =
                        results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                micButton.setEnabled(true);
                if (matches != null && !matches.isEmpty()) {
                    handleUserMessage(matches.get(0));
                } else {
                    statusText.setText("Awaaz samajh nahi aayi. Dobara boliye.");
                }
            }
            @Override public void onPartialResults(Bundle partialResults) {}
            @Override public void onEvent(int eventType, Bundle params) {}
        });
        speechRecognizer.startListening(intent);
    }

    private void handleUserMessage(String message) {
        conversationText.setText("You heard: " + message + "\n\nAURA: Processing...");
        statusText.setText("Recognized voice command");

        String appName = extractAppName(message);
        if (appName != null && launchApp(appName)) {
            String reply = appName + " khol raha hoon.";
            conversationText.setText("You: " + message + "\n\nAURA: " + reply);
            statusText.setText("App launch command completed");
            speak(reply);
            return;
        }

        if (appName != null) {
            String reply = "__unknown_app__".equals(appName)
                    ? "Kaunsa app kholna hai, ye samajh nahi aaya. App ka naam dobara boliye."
                    : appName + " app is phone mein nahi mila.";
            conversationText.setText("You: " + message + "\n\nAURA: " + reply);
            statusText.setText("App not found or command unclear");
            speak(reply);
            return;
        }

        askGemini(message);
    }

    // Detect app-opening commands locally. This must never depend on Gemini.
    private String extractAppName(String raw) {
        String text = normalize(raw);
        String compact = text.replace(" ", "");
        String[] openWords = {
                "open", "launch", "start", "khol", "kholo", "kholna",
                "khol do", "khol kar do", "open karo", "open kar do",
                "chalao", "chala do", "start karo", "खोल", "खोलो",
                "खोलना", "खोल दो", "खोलकर", "चालू करो", "चलाओ", "चला दो",
                "ओपन", "ओपन करो", "शुरू करो", "स्टार्ट"
        };
        boolean isOpenCommand = false;
        for (String word : openWords) {
            String w = normalize(word);
            if (!w.isEmpty() && text.contains(w)) { isOpenCommand = true; break; }
        }
        String[][] aliases = {
                {"youtube", "youtube", "you tube", "यूट्यूब", "यू ट्यूब", "यूटुब", "युट्यूब"},
                {"google", "google", "गूगल"},
                {"whatsapp", "whatsapp", "whats app", "वाट्सएप", "वाट्सऐप",
                        "व्हाट्सएप", "व्हाट्सऐप", "व्हाट्स अप", "वाट्स अप",
                        "व्हाट्सअप", "वॉट्सएप", "वॉट्सऐप", "व्हाट्स ऐप", "वाट्स ऐप"},
                {"chrome", "chrome", "क्रोम"},
                {"google maps", "google maps", "google map", "maps", "map",
                        "गूगल मैप्स", "गूगल मैप", "मैप्स", "मैप"},
                {"instagram", "instagram", "insta", "इंस्टाग्राम", "इंस्टा"},
                {"facebook", "facebook", "फेसबुक"},
                {"telegram", "telegram", "टेलीग्राम"},
                {"gmail", "gmail", "जीमेल"},
                {"camera", "camera", "कैमरा"},
                {"settings", "settings", "setting", "सेटिंग्स", "सेटिंग"},
                {"play store", "play store", "playstore", "प्ले स्टोर"},
                {"phone", "phone", "dialer", "फोन", "डायलर"},
                {"messages", "messages", "message", "मैसेज", "मैसेजेस", "संदेश"},
                {"gallery", "gallery", "गैलरी"},
                {"photos", "photos", "google photos", "फोटो", "गूगल फोटो", "गूगल फोटोज"},
                {"spotify", "spotify", "स्पॉटिफाई"},
                {"calculator", "calculator", "कैलकुलेटर"},
                {"clock", "clock", "घड़ी", "क्लॉक"}
        };
        for (String[] group : aliases) {
            for (int i = 1; i < group.length; i++) {
                String alias = normalize(group[i]);
                if (!alias.isEmpty() &&
                        (text.contains(alias) || compact.contains(alias.replace(" ", "")))) {
                    if (isOpenCommand || compact.equals(alias.replace(" ", ""))) return group[0];
                }
            }
        }
        if (isOpenCommand) {
            String commandText = text;
            String[] commandWords = {
                    "please", "open", "launch", "start", "khol", "kholo", "kholna",
                    "khol do", "khol kar do", "open karo", "open kar do",
                    "karo", "kar do", "chalao", "chala do", "start karo",
                    "खोल", "खोलो", "खोलना", "खोल दो", "खोलकर", "चालू करो",
                    "चलाओ", "चला दो", "ओपन", "ओपन करो", "शुरू करो", "स्टार्ट",
                    "जरा", "प्लीज"
            };
            for (String word : commandWords) {
                commandText = commandText.replace(normalize(word), " ").trim();
            }
            commandText = commandText.replaceAll("\\s+", " ").trim();
            String commandCompact = commandText.replace(" ", "");

            for (ResolveInfo info : getLaunchableApps()) {
                CharSequence label = info.loadLabel(getPackageManager());
                if (label != null) {
                    String labelNorm = normalize(label.toString());
                    String labelCompact = labelNorm.replace(" ", "");
                    if (!labelNorm.isEmpty() &&
                            (text.contains(labelNorm)
                            || compact.contains(labelCompact)
                            || commandText.equals(labelNorm)
                            || commandCompact.equals(labelCompact))) {
                        return label.toString();
                    }
                }
            }
            return "__unknown_app__";
        }
        return null;
    }

    private List<ResolveInfo> getLaunchableApps() {
        Intent query = new Intent(Intent.ACTION_MAIN, null);
        query.addCategory(Intent.CATEGORY_LAUNCHER);
        return getPackageManager().queryIntentActivities(query, 0);
    }

    private boolean launchApp(String requestedName) {
        String wanted = normalize(requestedName);

        // Explicit package mappings for common apps, including WhatsApp Business.
        String[][] packageAliases = {
                {"com.google.android.youtube", "youtube"},
                {"com.google.android.googlequicksearchbox", "google"},
                {"com.whatsapp", "whatsapp"},
                {"com.whatsapp.w4b", "whatsapp business"},
                {"com.android.chrome", "chrome"},
                {"com.google.android.apps.maps", "google maps"},
                {"com.instagram.android", "instagram"},
                {"com.facebook.katana", "facebook"},
                {"org.telegram.messenger", "telegram"},
                {"com.google.android.gm", "gmail"},
                {"com.android.camera2", "camera"},
                {"com.android.settings", "settings"},
                {"com.android.vending", "play store"},
                {"com.google.android.dialer", "phone"},
                {"com.google.android.apps.messaging", "messages"},
                {"com.google.android.apps.photos", "photos"},
                {"com.spotify.music", "spotify"},
                {"com.google.android.calculator", "calculator"},
                {"com.google.android.deskclock", "clock"}
        };

        for (String[] item : packageAliases) {
            if (wanted.equals(normalize(item[1]))) {
                Intent launch = getPackageManager().getLaunchIntentForPackage(item[0]);
                if (launch != null) {
                    try {
                        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(launch);
                        return true;
                    } catch (Exception ignored) {}
                }
            }
        }

        // Search all installed launcher apps so additional apps can also be opened.
        for (ResolveInfo info : getLaunchableApps()) {
            CharSequence label = info.loadLabel(getPackageManager());
            if (label != null && normalize(label.toString()).equals(wanted)) {
                Intent launch = new Intent(Intent.ACTION_MAIN);
                launch.addCategory(Intent.CATEGORY_LAUNCHER);
                launch.setClassName(info.activityInfo.packageName, info.activityInfo.name);
                try {
                    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(launch);
                    return true;
                } catch (Exception ignored) {}
            }
        }
        return false;
    }

    // Preserve Devanagari characters; the old normalizer removed Hindi letters,
    // which caused Hindi app names to fail matching.
    private String normalize(String value) {
        return Normalizer.normalize(value.toLowerCase(Locale.ROOT).trim(),
                Normalizer.Form.NFC)
                .replaceAll("[^a-z0-9\\u0900-\\u097F\\p{M} ]", " ")
                .replaceAll("\\s+", " ").trim();
    }

    private void askGemini(String message) {
        executor.execute(() -> {
            HttpURLConnection connection = null;
            try {
                URL url = new URL(WORKER_URL);
                connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("POST");
                connection.setConnectTimeout(20000);
                connection.setReadTimeout(30000);
                connection.setDoOutput(true);
                connection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");

                JSONObject payload = new JSONObject();
                payload.put("message", message);

                try (OutputStream os = connection.getOutputStream()) {
                    os.write(payload.toString().getBytes(StandardCharsets.UTF_8));
                }

                int code = connection.getResponseCode();
                InputStream stream = (code >= 200 && code < 300)
                        ? connection.getInputStream() : connection.getErrorStream();
                StringBuilder responseText = new StringBuilder();
                try (BufferedReader reader = new BufferedReader(
                        new InputStreamReader(stream, StandardCharsets.UTF_8))) {
                    String line;
                    while ((line = reader.readLine()) != null) responseText.append(line);
                }

                JSONObject result = new JSONObject(responseText.toString());
                if (code < 200 || code >= 300) {
                    String details = result.optString("details",
                            result.optString("error", "Server error"));
                    showReply("AI service error: " + details, false);
                    return;
                }

                String reply = result.optString("reply", "Mujhe jawab nahi mila.");
                showReply(reply, true);

            } catch (Exception e) {
                showReply("Internet ya server connection mein problem hai. " +
                        "Please dobara try karein.", false);
            } finally {
                if (connection != null) connection.disconnect();
            }
        });
    }

    private void showReply(String reply, boolean speakReply) {
        runOnUiThread(() -> {
            conversationText.setText("AURA: " + reply);
            statusText.setText("Ready");
            if (speakReply) speak(reply);
        });
    }

    private void speakAndShow(String message) {
        conversationText.setText("AURA: " + message);
        speak(message);
    }

    private void speak(String text) {
        if (ttsReady && tts != null) {
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "AURA_REPLY");
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions,
                                           int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_MIC && grantResults.length > 0
                && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startListening();
        } else if (requestCode == REQUEST_MIC) {
            statusText.setText("Microphone permission is required for voice commands.");
        }
    }

    @Override
    protected void onDestroy() {
        if (speechRecognizer != null) speechRecognizer.destroy();
        if (tts != null) tts.shutdown();
        if (executor != null) executor.shutdown();
        super.onDestroy();
    }
}
