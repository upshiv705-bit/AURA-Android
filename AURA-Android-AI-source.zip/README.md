# AURA Android Assistant — Source 1.0.6

- Android application ID: `com.aura.assistant` (same app identity for in-place update).
- Version: 1.0.6 (versionCode 7).
- Hindi/English app-opening commands are detected locally before any AI network request.
- Common apps have explicit package mappings; other installed launcher apps are matched by their visible names.
- Gemini chat continues through the existing Cloudflare Worker endpoint.
- Keep the Gemini API key only in the Cloudflare Worker secret `GEMINI_API_KEY`.

Build with Java 17 and Gradle 8.9:
`gradle assembleDebug`

APK output:
`app/build/outputs/apk/debug/app-debug.apk`
