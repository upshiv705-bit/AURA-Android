# AURA Android AI Assistant

This starter Android project listens in Hindi, sends the recognized text to the AURA Cloudflare Worker, displays the AI reply, and speaks it using Android Text-to-Speech.

Worker endpoint:
https://aura-ai-server.upshiv705.workers.dev

Build:
gradle assembleDebug

Important:
- The Gemini API key is not stored in this Android app. It must remain a Cloudflare Worker secret named GEMINI_API_KEY.
- Internet and microphone permissions are required.
- AI replies require internet access and are subject to the provider's free-tier limits.
