# AURA Android App Control Update

This source adds voice commands to open common installed Android apps while retaining
the existing Cloudflare Worker / Gemini chat connection.

Example commands:
- YouTube kholo
- WhatsApp kholo
- Open Chrome
- Instagram kholo

If the spoken sentence is not recognized as an app-opening command, it is sent to
the AURA AI Worker.

Build with Java 17 and Gradle 8.9:
    gradle assembleDebug

APK:
    app/build/outputs/apk/debug/app-debug.apk

The app uses the existing public Worker endpoint. Keep the Gemini API key only in
the Cloudflare Worker secret named GEMINI_API_KEY; never put it in this Android app.
