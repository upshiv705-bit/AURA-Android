# AURA Android starter
Hindi speech recognition and Hindi text-to-speech starter app.
The manifest declares Android's speech RecognitionService visibility query, required
for apps targeting Android 11/API 30 and above.
